#  The Boston house-price data of Harrison, D. and Rubinfeld, D.L. 'Hedonic
#  prices and the demand for clean air', J. Environ. Economics & Management,
#  vol.5, 81-102, 1978.   Used in Belsley, Kuh & Welsch, 'Regression diagnostics
#  ...', Wiley, 1980.   N.B. Various transformations are used in the table on
#  pages 244-261 of the latter.

#  Variables in order:
#  CRIM     per capita crime rate by town
#  ZN       proportion of residential land zoned for lots over 25,000 sq.ft.
#  INDUS    proportion of non-retail business acres per town
#  CHAS     Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
#  NOX      nitric oxides concentration (parts per 10 million)
#  RM       average number of rooms per dwelling
#  AGE      proportion of owner-occupied units built prior to 1940
#  DIS      weighted distances to five Boston employment centres
#  RAD      index of accessibility to radial highways
#  TAX      full-value property-tax rate per $10,000
#  PTRATIO  pupil-teacher ratio by town
#  B        1000(Bk - 0.63)^2 where Bk is the proportion of blacks by town
#  LSTAT    % lower status of the population
#  MEDV     Median value of owner-occupied homes in $1000's

import numpy as np
import pandas as pd
import statsmodels.api as sm

from sklearn import linear_model, datasets
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from statsmodels.tools.tools import add_constant

bd = pd.read_csv('boston.csv')
X = bd.values.copy()
X_train, X_test, Y_train, Y_test = train_test_split( X[:, :-1], X[:, -1],train_size=0.80)
result = sm.OLS( Y_train, add_constant(X_train) ).fit()

print(result.summary())

# LINEAR REGRESSION

linear_regression = linear_model.LinearRegression()

linear_regression.fit(X_train, Y_train)
linear_regression_predicted = linear_regression.predict(X_test)

linear_regression_train_score = linear_regression.score(X_train, Y_train)
linear_regression_test_score = linear_regression.score(X_test, Y_test)


print("\nLinear Regression\n")

print(f'Mean squared error: {mean_squared_error(Y_test, linear_regression_predicted)}')
print(f'Coefficient of determination: { r2_score(Y_test, linear_regression_predicted)}')
print(f'Linear Regression train score: {linear_regression_train_score}')
print(f'Linear Regression test score: {linear_regression_test_score}')

# RIDGE REGRESSION α = 0.1

ridge_regression_01 = linear_model.Ridge(alpha=0.1)
ridge_regression_01.fit(X_train, Y_train)

ridge_regression_01_train_score = ridge_regression_01.score(X_train, Y_train)
ridge_regression_01_test_score = ridge_regression_01.score(X_test, Y_test)

print("\nRidge Regression α = 0.1\n")

print(f'Mean squared error: {mean_squared_error(Y_test, ridge_regression_01.predict(X_test))}')
print(f'Coefficient of determination: { r2_score(Y_test, ridge_regression_01.predict(X_test))}')
print(f'Ridge Regression α = 0.1 train score: {ridge_regression_01_train_score}')
print(f'Ridge Regression α = 0.1 test score: {ridge_regression_01_test_score}\n')

# RIDGE REGRESSION α = 1

ridge_regression_1 = linear_model.Ridge(alpha=1)
ridge_regression_1.fit(X_train, Y_train)

ridge_regression_1_train_score = ridge_regression_1.score(X_train, Y_train)
ridge_regression_1_test_score = ridge_regression_1.score(X_test, Y_test)

print("\nRidge Regression α = 1\n")

print(f'Mean squared error: {mean_squared_error(Y_test, ridge_regression_1.predict(X_test))}')
print(f'Coefficient of determination: { r2_score(Y_test, ridge_regression_1.predict(X_test))}')
print(f'Ridge Regression α = 1 train score: {ridge_regression_1_train_score}')
print(f'Ridge Regression α = 1 test score: {ridge_regression_1_test_score}\n')

# RIDGE REGRESSION α = 5

ridge_regression_5 = linear_model.Ridge(alpha=5)
ridge_regression_5.fit(X_train, Y_train)

ridge_regression_5_train_score = ridge_regression_5.score(X_train, Y_train)
ridge_regression_5_test_score = ridge_regression_5.score(X_test, Y_test)

print("\nRidge Regression α = 5\n")

print(f'Mean squared error: {mean_squared_error(Y_test, ridge_regression_5.predict(X_test))}')
print(f'Coefficient of determination: { r2_score(Y_test, ridge_regression_5.predict(X_test))}')
print(f'Ridge Regression α = 5 train score: {ridge_regression_5_train_score}')
print(f'Ridge Regression α = 5 test score: {ridge_regression_5_test_score}\n')

# RIDGE REGRESSION α = 50

ridge_regression_50 = linear_model.Ridge(alpha=50)
ridge_regression_50.fit(X_train, Y_train)

ridge_regression_50_train_score = ridge_regression_50.score(X_train, Y_train)
ridge_regression_50_test_score = ridge_regression_50.score(X_test, Y_test)

print("\nRidge Regression α = 50\n")

print(f'Mean squared error: {mean_squared_error(Y_test, ridge_regression_50.predict(X_test))}')
print(f'Coefficient of determination: { r2_score(Y_test, ridge_regression_50.predict(X_test))}')
print(f'Ridge Regression α = 50 train score: {ridge_regression_50_train_score}')
print(f'Ridge Regression α = 50 test score: {ridge_regression_50_test_score}\n')

# LASSO REGRESSION α = 0.1

lasso_regression_01 = linear_model.Lasso(alpha=0.1)
lasso_regression_01.fit(X_train, Y_train)

lasso_regression_01.score(X_train, Y_train)
lasso_regression_01.score(X_test, Y_test)

print("\nLasso Regression α = 0.1\n")

print(lasso_regression_01.coef_)

# LASSO REGRESSION α = 1

lasso_regression_1 = linear_model.Lasso(alpha=1)
lasso_regression_1.fit(X_train, Y_train)

lasso_regression_1.score(X_train, Y_train)
lasso_regression_1.score(X_test, Y_test)

print("\nLasso Regression α = 1\n")

print(lasso_regression_1.coef_)

# LASSO REGRESSION α = 5

lasso_regression_5 = linear_model.Lasso(alpha=5)
lasso_regression_5.fit(X_train, Y_train)

lasso_regression_5.score(X_train, Y_train)
lasso_regression_5.score(X_test, Y_test)

print("\nLasso Regression α = 5\n")

print(lasso_regression_5.coef_)

# LASSO REGRESSION α = 50

lasso_regression_50 = linear_model.Lasso(alpha=50)
lasso_regression_50.fit(X_train, Y_train)

lasso_regression_50.score(X_train, Y_train)

print("\nLasso Regression α = 50\n")

print(lasso_regression_50.coef_)